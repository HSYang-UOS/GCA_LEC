package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import the.domain.dto.JpaBoardWriteDto;
import the.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired //일치하는 dataType이 있으면 일치시켜준다.
	private BoardService service;
	
	@RequestMapping("/board/list") // url주소 매핑
	public ModelAndView list() {   // @ResponseBody 생략되어 있음.
		System.out.println("컨트롤러 영역입니다.");
		return service.getList();
		//ModelAndView mv = service.getList(); return mv; 
		//return "/board/list"; // board폴더의 list.html 확장자 생략. /(root) 주소는 templates
	}
	@GetMapping("/board/write")
	public String write() {
		return "/board/write";
	}
	// method overloading
	@PostMapping("/board/write")
	public String write(JpaBoardWriteDto dto) { // Parameter 2개이상 > class로 바꾸어서 넣었다.
		System.out.println(dto);
		service.save(dto);
		return "redirect:/board/list";// sendRedirect썻던것과 같은 효과.
	}
	
	
}
