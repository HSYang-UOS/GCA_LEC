package the.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import the.domain.dto.JpaBoardResponseDto;
import the.domain.dto.JpaBoardWriteDto;
import the.domain.entity.JpaBoard;
import the.domain.entity.JpaBoardRepository;

@Service // 굳이 request response를 따로 요청, 응답해줄 필요 없다. 자동으로 해줌.
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private JpaBoardRepository repository;
	
	@Override
	public void save(JpaBoardWriteDto dto) {
		// 넘어온 data를 완성(제목 내용만 넘어왔다)
		// repository는 entity객체만 처리 가능.
		// dto객체를 entity객체로 변경.
		JpaBoard entity = dto.toEntity();
		
		// dao(repository)
		repository.save(entity);
	}

	@Override
	public ModelAndView getList() {
		ModelAndView mv = new ModelAndView("/board/list"); // 뷰 데이터 이름
		//mv.setViewName("/board/list");
		Sort sort = Sort.by(Direction.DESC, "no");
		
		List<JpaBoardResponseDto> list = repository.findAll(sort)
				.stream() // collection의 내용을 순서대로 나열
				.map(JpaBoardResponseDto::new) // JpaBoardResponseDto(JpaBoard) 생성자로 리턴
				.collect(Collectors.toList()); // 나열된 요소들을 다시 묶는 역할 collect
		
		
		mv.addObject("list",list); // model추가 : request.setAttribute(name,value)와 동일한 기능
		return mv;
	}
}
	/* 43번째 줄의 표현과 동일한 표현.
	 * List<JpaBoardResponseDto> list = repository.findAll(sort) 
	 * 				.stream() // collection의 내용을 순서대로 나열
	 *  			.map(e -> new JpaBoardResponseDto(e)) // 들어갈땐 JpaBoard 객체e 나올때는 JpaBoardResponseDto의 객체 e로 나온다.
	 * 				.collect(Collectors.toList()); // 나열된 요소들을 다시 묶는 역할 collect
	 */		
	// 첫번째 방법(너무 길다.) 43줄과 동일한 내용
	/* entity는 db와 직접 연결되어 있으므로, 위험성이 존재한다.
	 * entity 그대로 갖다 쓰지 않고, 따로 복제(list2)해서 가져다 쓰자
	 * List<JpaBoard> list = repository.findAll(sort);
	 * List<JpaBoardResponseDto> list2 = new Vector<>();
	 * 
	 * for(JpaBoard entity: list) { JpaBoardResponseDto dto = new
	 * JpaBoardResponseDto(entity); list2.add(dto); }
	 * mv.addObject("list",list2); // model추가 : request.setAttribute(name,value)와 동일한 기능
	 **/




