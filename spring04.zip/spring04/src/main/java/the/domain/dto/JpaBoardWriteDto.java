package the.domain.dto;

import lombok.Data;
import the.domain.entity.JpaBoard;

@Data
public class JpaBoardWriteDto {
	
	private String subject;
	private String content;
	
	public JpaBoard toEntity() {
		JpaBoard 
			 entity = JpaBoard.builder()
				 	.subject(subject).content(content).writer("guest")
				 	.build();
	 			 // builder의 내부클래스 접근해서 build메서드 접근. 원하는것을 각각 세팅할 수 있음.
		//JpaBoard entity = new JpaBoard(subject, content, "gueset");
		return entity;
	}
}