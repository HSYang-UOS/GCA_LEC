package the.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// dao(data access object) 역할. - 물리적 db와 연결. 실질적 데이터 전송 역할 담당.
@Repository // 생략가능한annotation						//<entity클래스이름: JpaBoard, ID(PK값)의 dataType: Long>
public interface JpaBoardRepository extends JpaRepository<JpaBoard, Long>{ // 저장할지에 대한 것은 Repository에 있다. 
	
}
