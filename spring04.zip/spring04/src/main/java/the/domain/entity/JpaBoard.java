package the.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Builder
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class) // Entity에 대해서 감시(audit)하는 역할 > Listener
@SequenceGenerator(name = "seq_jpaboard_generator",
				   sequenceName ="seq_jpaboard", 
				   initialValue = 1, allocationSize = 1)
@RequiredArgsConstructor
@Getter
@Entity
public class JpaBoard {
	
	
//
//	public JpaBoard(String subject, String content, String writer) {
//		super();
//		this.subject = subject;
//		this.content = content;
//		this.writer = writer;
//	}
	
	//generator의 값을 이용하여 no에 자동 세팅
	@GeneratedValue(generator = "seq_jpaboard_generator",strategy = GenerationType.IDENTITY) // 번호 자동 생성
	@Id // Primary Key임을 표시	
	private long no;
	
	@Column(nullable = false)	
	private String subject;
	
	@Column(nullable = false)
	private String content;
	
	@Column
	private int readCount; // 카멜표기로 쓰자.
	
	@Column(nullable = false)
	private String writer;
	
	@CreatedDate
	@Column
	private LocalDateTime createdDate;
	
	@LastModifiedDate
	@Column
	private LocalDateTime updatedDate;
		
}
// entity를 만들때는 항상 dao도 만들것을 염두하여야 한다.
// C는 Constructor. S는 Static
