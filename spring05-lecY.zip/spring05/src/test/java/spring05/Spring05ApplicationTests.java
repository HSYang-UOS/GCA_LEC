package spring05;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import spring05.domain.entity.BoardRepository;
import spring05.domain.entity.JpaMemo;

@SpringBootTest
class Spring05ApplicationTests {
	
	@Autowired
	BoardRepository boardRepository;
	
	// @Test
	void contextLoads() {		}

	//@Test
	void 메모데이터삽입() {
		for(int i = 1; i<=100; i++) {
			JpaMemo entity = JpaMemo.builder().text("내용"+i).writer("작성자"+(i%10+1)).build();
			boardRepository.save(entity);
		}
		
	}
}
