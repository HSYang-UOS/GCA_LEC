package spring05.service;


import org.springframework.ui.Model;

import spring05.domain.dto.JpaMemoRequestDto;


public interface BoardService {
	
	void write(JpaMemoRequestDto dto);


	void findAll(int page, Model model);

	void findByAll(Model model);

}
