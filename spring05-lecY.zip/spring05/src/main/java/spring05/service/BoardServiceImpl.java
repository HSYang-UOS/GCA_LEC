package spring05.service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import spring05.domain.dto.JpaMemoRequestDto;
import spring05.domain.dto.JpaMemoResponseDto;
import spring05.domain.entity.BoardRepository;
import spring05.domain.entity.JpaMemo;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	BoardRepository repository;

	@Override
	public void write(JpaMemoRequestDto dto) {
		System.out.println(repository);
		// DB : dao역할을 하는 Repository
		repository.save(dto.toEntity()); // DB에 저장. entity와 연결되어있는 객체 저장하기위해 Entity객체로 변환(toEntity()사용)해서 넣는다.
		// Hibernate: select seq_memo_gen.nextval from dual
		// Hibernate: insert into jpa_memo_test (created_date, text, updated_date, writer, no) values (?, ?, ?, ?, ?)
		
	}

	@Override
	public void findByAll(Model model) {
		// memo DB모든 데이터를 가져와서...페이지로 이동 : model을 통해서 가져간다.
		// DB정보는 Entity정보(JpaMemo)로 반환합니다.
		
		Sort sort = Sort.by(Direction.DESC,"no");
		List<JpaMemo> result = repository.findAll(sort); // 원본 데이터이기 때문에 새로운 걸로 받아서 넣자.
		//Entity정보를 데이터의 안전성을 위해, JpaMemoResponseDto를 만들어 필요한 데이터를 가져다 쓰자.
		// Entity > Dto
		List<JpaMemoResponseDto> result_t = result.stream()
												  .map(JpaMemoResponseDto::new)
												  .collect(Collectors.toList());
		model.addAttribute("toDay", LocalDate.now());
		model.addAttribute("list", result_t);		
		}

	@Override
	public void findAll(int page, Model model) {	
		int size = 10; // 한 페이지의 게시글 수 
		System.out.println("페이지 index 번호: "+page);
		
		Sort sort = Sort.by(Direction.DESC,"no");
		Pageable pageable = PageRequest.of(page, size, sort); // 0페이지부터 페이지 마다 10개의 데이터를 넣고, 내림차순 sort
		
		Page<JpaMemo> pageObj = repository.findAll(pageable);
		System.out.println("총 페이지의 수 : "+pageObj.getTotalPages());
		// 페이지 객체에서 게시글 내용만 추출
		List<JpaMemo> result = pageObj.getContent();
		// Entity > Dto
		List<JpaMemoResponseDto> list = result.stream()
												  .map(JpaMemoResponseDto::new)
												  .collect(Collectors.toList());
		model.addAttribute("toDay", LocalDate.now());
		model.addAttribute("list", list);		
		
	}

}
