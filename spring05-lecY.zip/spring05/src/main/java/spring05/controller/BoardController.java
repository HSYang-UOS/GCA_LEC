package spring05.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import spring05.domain.dto.JpaMemoRequestDto;
import spring05.service.BoardService;
import spring05.service.BoardServiceImpl;

// @RequestMapping("/board")
@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	@GetMapping("/board/list1") 
	public String list(Model model) {
		service.findByAll(model);
		return "/board/list"; // /board/list.html 을 지정(확장자 생략)
	}

	// @RequestMapping(value = "/board/list", method = RequestMethod.GET) 대신 사용.
	// 리스트 메뉴 클릭시
	@GetMapping("/board/list") 
	public String list(@RequestParam(defaultValue = "0") int page,Model model) {
		service.findAll(page, model);
		return "/board/list"; // /board/list.html 을 지정(확장자 생략)
	}
	
	// 글쓰기페이지 이동
	@GetMapping("/board/write")  
	public String write() {
		return "/board/write"; 
	}
	// 글쓰기 처리
	@PostMapping("/board/write") 
	public String write(JpaMemoRequestDto dto) {
		service.write(dto); // dto정보를 받아서 write해주세요.
		
		return "redirect:/board/list"; 
	}
}
