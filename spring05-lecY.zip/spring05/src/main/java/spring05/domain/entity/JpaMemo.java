package spring05.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

// Auditing : 감시하는 역할. entity객체가 생성/수정이 될때, 날짜를 자동으로 업데이트
@EntityListeners(AuditingEntityListener.class)
@SequenceGenerator(name = "memo_generator", 
				   sequenceName = "seq_memo_gen",
				   initialValue = 1,
				   allocationSize = 1 )
@Table(name="jpa_memo_test")
@RequiredArgsConstructor
@Getter
@Entity
public class JpaMemo {
	
	@Id // pk지정
	@GeneratedValue(generator = "memo_generator", strategy = GenerationType.SEQUENCE)
	private long no;
	@Column(nullable = false)
	private String text;
	@Column(nullable = false)
	private String writer;
	
	@CreatedDate
	@Column
	private LocalDateTime createdDate;
	@LastModifiedDate
	@Column
	private LocalDateTime updatedDate;
	
	@Builder // static inner 클래스가 만들어진다.
	public JpaMemo(String text, String writer) {
		this.text = text;
		this.writer = writer;
	}
}
