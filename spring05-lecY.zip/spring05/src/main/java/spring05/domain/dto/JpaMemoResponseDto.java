package spring05.domain.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import spring05.domain.entity.JpaMemo;

@RequiredArgsConstructor
@AllArgsConstructor
@Data
public class JpaMemoResponseDto {
	
	private long no;
	private String text;
	private String writer;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	// entity컬럼의 데이터를 dto컬럼으로 저장하기 위한 생성자.
	//생성자 파라미터에 entity객체가 들어와서 dto에 매핑 따라서 생성자 필요 없음
	public JpaMemoResponseDto(JpaMemo entity) {
		this.no = entity.getNo();
		this.text = entity.getText();
		this.writer = entity.getWriter();
		this.createdDate = entity.getCreatedDate();
		this.updatedDate = entity.getUpdatedDate();				
	}
}
