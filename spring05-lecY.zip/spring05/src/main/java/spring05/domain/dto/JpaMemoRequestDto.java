package spring05.domain.dto;

import lombok.Data;
import spring05.domain.entity.JpaMemo;

@Data
public class JpaMemoRequestDto {
	private String text;
	private String writer;
	
	// data를 entity객체로 세팅하기 위한 method
	public JpaMemo toEntity() {
		//return new JpaMemo(text,writer); 아래와 같은 내용.
		return JpaMemo.builder()
					  .text(text).writer(writer)
					  .build();
	}
}
